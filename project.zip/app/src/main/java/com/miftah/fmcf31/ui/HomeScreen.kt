package com.miftah.fmcf31.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.miftah.fmcf31.data.*
import kotlinx.coroutines.delay
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DHAKA: ZoneId = ZoneId.of("Asia/Dhaka")
private val DATE_FMT = DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH)
private val CLOCK_FMT = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.ENGLISH)
private val TIME_FMT = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
private val FINAL_PROF = ZonedDateTime.of(2027, 5, 2, 0, 0, 0, 0, DHAKA)
private val COUNTDOWN_LINES = listOf(
    "Every day counts.",
    "Future surgeon loading.",
    "Summer is coming. Final Prof is coming faster.",
    "Your future patients are counting on your knowledge."
)

@Composable
fun HomeScreen(student: Student, onSwitch: () -> Unit) {
    var now by remember { mutableStateOf(ZonedDateTime.now(DHAKA)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now(DHAKA)
            delay(1000)
        }
    }
    var offset by remember { mutableIntStateOf(0) }
    val today = now.toLocalDate()
    val date: LocalDate = today.plusDays(offset.toLong())
    val slots = remember(date, student) { Routine.slotsFor(date, student) }
    val isBlockPosting = !date.isBefore(Routine.BLOCK_START)
    val message = remember(now.hour, today, student) { Messages.pick(student, now) }
    val onSurface = MaterialTheme.colorScheme.onSurface

    LazyColumn(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Date + live clock (top-left) and home/switch action
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(now.format(DATE_FMT), style = MaterialTheme.typography.labelLarge, color = onSurface.copy(alpha = 0.7f))
                    Text(now.format(CLOCK_FMT), fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = onSurface)
                }
                TextButton(onClick = onSwitch) { Text("Change roll") }
            }
        }
        item {
            AppCard {
                Text("Welcome, ${student.displayName}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = onSurface)
                Text(student.name, style = MaterialTheme.typography.bodyMedium, color = onSurface.copy(alpha = 0.75f))
                Text("Roll ${student.roll} · Group ${student.group}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                Text(message, style = MaterialTheme.typography.bodyMedium, color = onSurface)
            }
        }
        item { CountdownCard(now) }

        // Routine
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { offset-- }) { Text("‹ Prev") }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        when (offset) { 0 -> "Today"; 1 -> "Tomorrow"; -1 -> "Yesterday"; else -> date.dayOfWeek.name.lowercase().replaceFirstChar { it.uppercase() } },
                        fontWeight = FontWeight.SemiBold, color = onSurface
                    )
                    Text(date.format(DATE_FMT), style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.7f))
                }
                TextButton(onClick = { offset++ }) { Text("Next ›") }
            }
        }
        if (offset != 0) {
            item { TextButton(onClick = { offset = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Back to today") } }
        }
        when {
            isBlockPosting -> item {
                AppCard {
                    Text("Block Posting", fontWeight = FontWeight.SemiBold, color = onSurface)
                    Text("Block posting starts from December 2026. Day-wise department, ward and roster details are awaiting administrator input.", color = onSurface.copy(alpha = 0.8f))
                }
            }
            slots.isEmpty() -> item {
                AppCard { Text("No scheduled academic activity in the default routine for this day.", color = onSurface.copy(alpha = 0.8f)) }
            }
            else -> {
                item { Text("Default routine · not yet confirmed by an official notice", style = MaterialTheme.typography.labelMedium, color = onSurface.copy(alpha = 0.65f)) }
                items(slots) { slot ->
                    val live = date == today && !now.toLocalTime().isBefore(slot.start) && now.toLocalTime().isBefore(slot.end)
                    SlotRow(slot, live)
                }
            }
        }
        if (!isBlockPosting && date.dayOfWeek == DayOfWeek.THURSDAY) {
            item {
                Text(
                    "Note: the SGT placement schedule also lists a Thursday 1:30–2:30 PM session. It is not shown because it conflicts with 'no class after 1:00 PM'. Awaiting admin confirmation.",
                    style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.65f)
                )
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Made with Md Miftahul Islam · F-31172", style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.6f))
                Text("© 2026 Md Miftahul Islam", style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun AppCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun CountdownCard(now: ZonedDateTime) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    AppCard {
        Text("Final Prof countdown", fontWeight = FontWeight.SemiBold, color = onSurface)
        Text("Provisional date: 2 May 2027 (not officially confirmed)", style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.7f))
        Spacer(Modifier.height(10.dp))
        val d = Duration.between(now, FINAL_PROF)
        if (d.isNegative) {
            Text("The provisional date has arrived.", color = onSurface)
        } else {
            Row(Modifier.fillMaxWidth()) {
                CountBox("Days", d.toDays())
                CountBox("Hours", d.toHours() % 24)
                CountBox("Min", d.toMinutes() % 60)
                CountBox("Sec", d.seconds % 60)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(COUNTDOWN_LINES[now.dayOfYear % COUNTDOWN_LINES.size], style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.7f))
    }
}

@Composable
private fun RowScope.CountBox(label: String, value: Long) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}

private fun badgeColor(t: ActType): Color = when (t) {
    ActType.LECTURE -> Color(0xFF2563EB)
    ActType.WARD -> Color(0xFF15803D)
    ActType.SGT -> Color(0xFFC2410C)
    ActType.SEMINAR -> Color(0xFF7E22CE)
    ActType.GIT -> Color(0xFF0E7490)
    ActType.DIT -> Color(0xFF4338CA)
    ActType.PRAYER -> Color(0xFF64748B)
}

@Composable
private fun SlotRow(slot: Slot, live: Boolean) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val inactive = slot.status in setOf(Status.CANCELLED, Status.POSTPONED, Status.NO_CLASS)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (live) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(badgeColor(slot.type)),
                contentAlignment = Alignment.Center
            ) {
                Text(slot.type.code, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    slot.title, fontWeight = FontWeight.SemiBold, color = onSurface,
                    textDecoration = if (inactive) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    slot.start.format(TIME_FMT) + " – " + slot.end.format(TIME_FMT),
                    style = MaterialTheme.typography.bodySmall, color = onSurface.copy(alpha = 0.75f)
                )
                slot.detail?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
                if (slot.status != Status.DEFAULT) {
                    Text(slot.status.label.uppercase(), style = MaterialTheme.typography.labelSmall, color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                }
            }
            if (live) Text("NOW", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
    }
}
