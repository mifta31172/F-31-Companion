package com.miftah.fmcf31.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

enum class ActType(val label: String, val code: String) {
    LECTURE("Lecture", "LEC"),
    WARD("Ward", "WRD"),
    SGT("SGT", "SGT"),
    SEMINAR("Seminar", "SEM"),
    GIT("General Integrated Teaching", "GIT"),
    DIT("Departmental Integrated Teaching", "DIT"),
    PRAYER("Prayer & Lunch", "P&L")
}

/** DEFAULT = routine from the base timetable. Admin (Phase 3) will set the others. */
enum class Status(val label: String) {
    DEFAULT("Default routine"),
    CONFIRMED("Confirmed"),
    CANCELLED("Cancelled"),
    POSTPONED("Postponed"),
    RESCHEDULED("Rescheduled"),
    NO_CLASS("No class")
}

data class Slot(
    val start: LocalTime,
    val end: LocalTime,
    val type: ActType,
    val title: String,
    val detail: String? = null,
    val status: Status = Status.DEFAULT
)

object Routine {
    val BLOCK_START: LocalDate = LocalDate.of(2026, 12, 1)

    private fun t(h: Int, m: Int = 0): LocalTime = LocalTime.of(h, m)

    fun slotsFor(date: LocalDate, s: Student): List<Slot> {
        if (!date.isBefore(BLOCK_START)) return emptyList()
        val g = s.group
        val dow = date.dayOfWeek
        val lecture = Slot(t(8), t(9), ActType.LECTURE, "Lecture")
        val ward = Slot(t(9), t(11), ActType.WARD, "Ward", Ward.posting(date, g))
        val dit = Slot(t(12), t(14, 30), ActType.DIT, "Departmental Integrated Teaching")
        val lunch = Slot(t(13), t(13, 30), ActType.PRAYER, "Prayer & Lunch")
        fun sgt(n: Int, a: LocalTime, b: LocalTime, title: String = "SGT") =
            Slot(a, b, ActType.SGT, title, Sgt.dept(dow, n, g)?.let { "Group $g: $it" })

        return when (dow) {
            DayOfWeek.SATURDAY -> listOf(
                lecture, ward,
                Slot(t(11), t(14, 30), ActType.GIT, "General Integrated Teaching")
            )
            DayOfWeek.SUNDAY, DayOfWeek.WEDNESDAY -> listOf(lecture, ward, sgt(1, t(11), t(12)), dit)
            DayOfWeek.MONDAY -> listOf(
                lecture, ward, sgt(1, t(11), t(12)), lunch,
                Slot(t(13, 30), t(14, 30), ActType.LECTURE, "Lecture")
            )
            DayOfWeek.TUESDAY -> listOf(
                lecture,
                Slot(t(9), t(10), ActType.SEMINAR, "Seminar"),
                Slot(t(10), t(11), ActType.WARD, "Ward", Ward.posting(date, g)),
                sgt(1, t(11), t(12)),
                dit
            )
            DayOfWeek.THURSDAY -> listOf(
                lecture, ward,
                sgt(1, t(11), t(12), "SGT 1"),
                sgt(2, t(12), t(13), "SGT 2")
            )
            else -> emptyList()
        }
    }
}

/** Source: Principal's office, Phase IV SGT Placement Schedule (memo dated 08/01/26). */
object Sgt {
    val columns = listOf(
        "Internal Medicine",
        "Paediatrics / Dermatology / Psychiatry (current rotation: awaiting admin)",
        "Surgery / Urology / Orthopaedics / Paediatric Surgery (current rotation: awaiting admin)",
        "Eye / ENT (current rotation: awaiting admin)",
        "Gynaecology & Obstetrics"
    )

    // key = (day, session no.), value = groups for each column above
    private val table: Map<Pair<DayOfWeek, Int>, List<String>> = mapOf(
        (DayOfWeek.SUNDAY to 1) to listOf("AB", "C", "E", "F", "D"),
        (DayOfWeek.MONDAY to 1) to listOf("DE", "F", "A", "B", "C"),
        (DayOfWeek.TUESDAY to 1) to listOf("AC", "B", "D", "E", "F"),
        (DayOfWeek.WEDNESDAY to 1) to listOf("EF", "D", "B", "C", "A"),
        (DayOfWeek.THURSDAY to 1) to listOf("BC", "A", "F", "D", "E"),
        (DayOfWeek.THURSDAY to 2) to listOf("DF", "E", "C", "A", "B")
    )

    fun dept(day: DayOfWeek, session: Int, group: Char): String? {
        val row = table[day to session] ?: return null
        val i = row.indexOfFirst { group.toString() in it }
        return if (i >= 0) columns[i] else null
    }
}

/** Source: Medicine Dept, 5th Year Clinical Class Schedule for Medicine Ward (F31), 01.11.26-30.11.26. */
object Ward {
    private val periods = listOf(
        LocalDate.of(2026, 11, 1) to LocalDate.of(2026, 11, 5),
        LocalDate.of(2026, 11, 7) to LocalDate.of(2026, 11, 11),
        LocalDate.of(2026, 11, 12) to LocalDate.of(2026, 11, 17),
        LocalDate.of(2026, 11, 18) to LocalDate.of(2026, 11, 23),
        LocalDate.of(2026, 11, 24) to LocalDate.of(2026, 11, 29)
    )

    private val units: Map<Char, List<String>> = mapOf(
        'A' to listOf("Paediatrics", "Gastroenterology", "Cardiology", "Medicine unit-01", "Medicine unit-02"),
        'B' to listOf("Medicine unit-03", "Paediatrics", "Gastroenterology", "Cardiology", "Medicine unit-04"),
        'C' to listOf("Medicine unit-05", "Medicine unit-01", "Paediatrics", "Gastroenterology", "Cardiology"),
        'D' to listOf("Cardiology", "Medicine unit-02", "Medicine unit-03", "Paediatrics", "Gastroenterology"),
        'E' to listOf("Gastroenterology", "Medicine unit-04", "Medicine unit-05", "Medicine unit-02", "Paediatrics"),
        'F' to listOf("Paediatrics", "Cardiology", "Medicine unit-01", "Medicine unit-03", "Medicine unit-05")
    )

    fun posting(date: LocalDate, group: Char): String? {
        if (date == LocalDate.of(2026, 11, 30)) return "Medicine Dept: Feedback class"
        val i = periods.indexOfFirst { !date.isBefore(it.first) && !date.isAfter(it.second) }
        if (i < 0) return null
        return "Medicine ward posting: " + units[group]!![i]
    }
}
