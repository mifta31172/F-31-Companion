package com.miftah.fmcf31.data

import android.content.Context

data class Student(val roll: String, val name: String, val nickname: String) {
    val number: Int get() = roll.takeLast(3).toInt()
    val group: Char get() = groupOf(number)

    private val firstName: String
        get() {
            val skip = setOf("md", "mst", "mohammad", "mohammed", "most", "muhammad")
            val parts = name.split(" ").filter { it.isNotBlank() }
            return parts.firstOrNull { it.lowercase().trimEnd('.') !in skip } ?: name
        }

    /** Registered nickname if the admin has set one, otherwise the first given name. */
    val displayName: String get() = if (nickname.isNotBlank()) nickname else firstName
}

fun groupOf(n: Int): Char = when {
    n <= 30 -> 'A'
    n <= 60 -> 'B'
    n <= 90 -> 'C'
    n <= 120 -> 'D'
    n <= 150 -> 'E'
    else -> 'F'
}

object StudentRepo {
    fun load(ctx: Context): List<Student> =
        ctx.assets.open("students.csv").bufferedReader().useLines { lines ->
            lines.drop(1).mapNotNull { l ->
                val p = l.split(",")
                if (p.size < 2) null else Student(p[0].trim(), p[1].trim(), p.getOrElse(2) { "" }.trim())
            }.toList()
        }

    /** Accepts "F31172", "f31 172" or just "172". */
    fun find(all: List<Student>, input: String): Student? {
        val s = input.uppercase().filter { it.isLetterOrDigit() }
        val digits = if (s.startsWith("F31")) s.drop(3) else s
        if (digits.isEmpty() || digits.length > 3 || !digits.all { it.isDigit() }) return null
        val roll = "F31" + digits.padStart(3, '0')
        return all.firstOrNull { it.roll == roll }
    }
}
