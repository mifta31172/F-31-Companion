package com.miftah.fmcf31.data

import java.time.ZonedDateTime

/** Deterministic per-student, per-hour rotation. Consecutive hours never repeat (step 7 is coprime to pool sizes). */
object Messages {
    private val classHours = listOf(
        "{n}, ward rounds reward the prepared. Warm up with the history, finish with the examination.",
        "Good morning, {n}. The patient will not wait until you feel ready, so be ready.",
        "{n}, a good clinician reads the chart before the consultant does.",
        "Attendance is the cheapest way to learn what no textbook will tell you, {n}.",
        "{n}, one clinical sign remembered today is one mark earned in the viva.",
        "Reminder for {n}: a stethoscope works better when it is not in the bag.",
        "{n}, ask the patient one more question than yesterday. That is how experience compounds.",
        "Clinical fact: Charcot's triad (fever, jaundice, right upper quadrant pain) points to ascending cholangitis.",
        "Clinical fact: Beck's triad (hypotension, raised JVP, muffled heart sounds) suggests cardiac tamponade.",
        "{n}, if the lecture feels long, remember that the exam hall feels longer."
    )

    private val afterClass = listOf(
        "{n}, class is over; revision is not. Thirty focused minutes tonight is enough to start.",
        "Evening note for {n}: write down three things you saw on the ward today before they fade.",
        "{n}, the best time to open the book was this morning. The second best is now.",
        "Clinical fact: Virchow's triad is stasis, endothelial injury and hypercoagulability.",
        "Clinical fact: Cushing's triad (hypertension, bradycardia, irregular respiration) signals raised intracranial pressure.",
        "{n}, rest matters too. Sleep is when today's clinical pearls get filed away.",
        "Clinical fact: Whipple's triad confirms true hypoglycaemia: symptoms, a documented low glucose, relief when glucose is given.",
        "{n}, tomorrow's lecture topic deserves five minutes tonight. Future you will be grateful."
    )

    fun pick(s: Student, now: ZonedDateTime): String {
        val afterHours = now.hour >= 15 || now.hour < 8 || (now.hour == 14 && now.minute >= 30)
        val pool = if (afterHours) afterClass else classHours
        val idx = Math.floorMod(s.number + now.hour * 7 + now.dayOfYear * 3, pool.size)
        return pool[idx].replace("{n}", s.displayName)
    }
}
