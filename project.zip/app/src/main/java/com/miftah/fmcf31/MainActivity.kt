package com.miftah.fmcf31

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.miftah.fmcf31.data.StudentRepo
import com.miftah.fmcf31.data.Student
import com.miftah.fmcf31.ui.FmcTheme
import com.miftah.fmcf31.ui.HomeScreen
import com.miftah.fmcf31.ui.LoginScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FmcTheme { AppRoot() } }
    }
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val students = remember { StudentRepo.load(ctx) }
    val prefs = remember { ctx.getSharedPreferences("fmc", Context.MODE_PRIVATE) }
    var student by remember {
        mutableStateOf<Student?>(prefs.getString("roll", null)?.let { r -> students.firstOrNull { it.roll == r } })
    }
    val current = student
    if (current == null) {
        LoginScreen(students) { s ->
            prefs.edit().putString("roll", s.roll).apply()
            student = s
        }
    } else {
        HomeScreen(current) {
            prefs.edit().remove("roll").apply()
            student = null
        }
    }
}
